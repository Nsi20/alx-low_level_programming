#!/bin/sh

mkdir -p autotools m4
autoreconf --force --install
