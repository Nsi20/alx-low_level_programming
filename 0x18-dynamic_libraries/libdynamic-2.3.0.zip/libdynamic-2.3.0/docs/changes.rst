*********************
Changes in libdynamic
*********************

.. include:: ../CHANGES
